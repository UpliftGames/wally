local Minimal = require(script.Parent.Minimal)

return function()
	print(Minimal)
end