local Indirect = require(script.Parent.Indirect)

return Indirect == 420