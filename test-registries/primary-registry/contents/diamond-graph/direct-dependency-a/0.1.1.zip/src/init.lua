local Indirect = require(script.Parent.Indirect)

return if Indirect == 420 then "Bingo!" else "Naw..."