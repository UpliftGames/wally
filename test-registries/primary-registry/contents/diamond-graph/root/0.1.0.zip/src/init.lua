local A = require(script.Parent.A)
local B = require(script.Parent.B)

return `{A} {B}`