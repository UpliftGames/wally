return function()
	return 42
end
