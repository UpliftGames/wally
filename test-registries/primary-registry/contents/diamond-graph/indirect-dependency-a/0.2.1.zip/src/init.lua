-- Deviously breaking everything
return function()
	return 69
end
